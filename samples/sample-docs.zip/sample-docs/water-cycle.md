# The Water Cycle

The water cycle describes how water moves through Earth's systems. Solar energy
evaporates water from oceans and lakes into vapour. The vapour rises, cools, and
**condenses** into clouds. When droplets grow heavy they fall as precipitation —
rain, snow, or hail. Water then collects in rivers and aquifers and flows back to
the sea, and the cycle repeats. Plants contribute through transpiration.
